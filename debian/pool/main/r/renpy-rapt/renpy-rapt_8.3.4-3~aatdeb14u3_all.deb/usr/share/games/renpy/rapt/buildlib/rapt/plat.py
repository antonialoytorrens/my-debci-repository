# This sets up various variables and commands based on the platform we're on.

from __future__ import print_function

##############################################################################
# These are set based on the platform we're on.
windows = False
macintosh = False
linux = False

import sys
import os
import platform
import traceback
import shutil
import subprocess


def translate(s):
    """
    This is intended to be replaced when this module is imported from Ren'Py
    proper, to translate `s` itself.
    """

    return s


def __(s):
    """
    This is imported into the other modules. It's called to translate `s`,
    which is
    """

    return translate(s)


def maybe_java_home(s):
    """
    If JAVA_HOME is in the environ, return $JAVA_HOME/bin/s. Otherwise, return
    s.
    """

    if "JAVA_HOME" in os.environ:
        binary_file_path = os.path.join(os.environ["JAVA_HOME"], "bin", s)
        if not os.path.exists(binary_file_path):
            return s

        return binary_file_path
    else:
        return s


if platform.win32_ver()[0]:
    windows = True

    adb = "platform-tools\\adb.exe"
    sdkmanager = "cmdline-tools\\latest\\bin\\sdkmanager.bat"

    java = maybe_java_home("java.exe")
    javac = maybe_java_home("javac.exe")
    keytool = maybe_java_home("keytool.exe")

    gradlew = "project/gradlew.bat"

elif platform.mac_ver()[0]:
    macintosh = True

    adb = "platform-tools/adb"
    sdkmanager = "cmdline-tools/latest/bin/sdkmanager"

    java = maybe_java_home("java")
    javac = maybe_java_home("javac")
    keytool = maybe_java_home("keytool")

    gradlew = "project/gradlew"

else:
    linux = True

    adb = "platform-tools/adb"
    sdkmanager = "cmdline-tools/latest/bin/sdkmanager"

    java = maybe_java_home("java")
    javac = maybe_java_home("javac")
    keytool = maybe_java_home("keytool")

    gradlew = "project/gradlew"

# The path to RAPT.

if sys.version_info.major >= 3:
    RAPT_PATH = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
else:
    RAPT_PATH = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__.decode(sys.getfilesystemencoding())))))


RAPT_SHARE = RAPT_PATH
_STATIC_PREFIXES = (
    "prototype",
    "templates",
    "buildlib",
    "bundletool.jar",
    "hash.txt",
    "sdk.txt",
)


def _default_rapt_home():
    env = os.environ.get("RAPT_HOME")
    if env:
        return env
    xdg = os.environ.get("XDG_CACHE_HOME")
    if xdg:
        return os.path.join(xdg, "renpy-rapt")
    return os.path.join(os.path.expanduser("~"), ".cache", "renpy-rapt")


RAPT_HOME = _default_rapt_home()


def path(path, relative=False):
    """
    Turns a relative path into an absolute path.

    Packaged files resolve under RAPT_SHARE (/usr/share/.../rapt).
    Writable runtime files resolve under RAPT_HOME.
    """

    if not path:
        return RAPT_SHARE

    if not relative:
        first = path.replace("\\", "/").split("/")[0]
        if path in (".", os.curdir):
            base = RAPT_HOME
        elif first in _STATIC_PREFIXES:
            base = RAPT_SHARE
        else:
            base = RAPT_HOME
        if base == RAPT_HOME and not os.path.isdir(RAPT_HOME):
            os.makedirs(RAPT_HOME)
        path = os.path.join(base, path)

    return path

jdk_requirement = 21
sdk_version = "11076708_latest"

try:
    with open(path("sdk.txt")) as f:
        sdk = f.read().strip()
except:
    sdk = path("Sdk")

adb = os.path.join(sdk, adb)
sdkmanager = os.path.join(sdk, sdkmanager)

gradlew = path(gradlew)

# This gets set in the Ren'Py launcher if we're a Ren'Py build.
renpy = False


def rename(src, dst):
    """
    Renames src to dst.
    """

    if os.path.isdir(dst):
        shutil.rmtree(dst)
    elif os.path.exists(dst):
        os.unlink(dst)

    if os.path.isdir(src):
        shutil.copytree(src, dst)
        shutil.rmtree(src)
    else:
        shutil.copy(src, dst)
        os.unlink(src)
