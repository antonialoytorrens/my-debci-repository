# Debian launcher helpers for CLI web_build / distribute without the full SDK.
# Installed by renpy-web into launcher/game/ so the launcher loads it automatically.

init 999 python:
    import os
    import shutil

    _build_web = build_web
    _add_file = distribute.Distributor.add_file
    _copy = shutil.copy

    def _is_optional_sdk_binary(path):
        if not path.endswith("/renpy"):
            return False
        return "linux-x86_64" in path or "mac-universal" in path

    def _copy_skip_dirs(src, dst, *args, **kwargs):
        if os.path.isdir(src):
            return dst
        return _copy(src, dst, *args, **kwargs)

    def build_web(p, *args, **kwargs):
        old_current = project.current
        project.current = p
        shutil.copy = _copy_skip_dirs
        try:
            return _build_web(p, *args, **kwargs)
        finally:
            shutil.copy = _copy
            project.current = old_current

    def _add_file_skip_missing_sdk(self, file_list, name, path, executable=False):
        if not os.path.exists(path) and _is_optional_sdk_binary(path):
            return
        return _add_file(self, file_list, name, path, executable=executable)

    distribute.Distributor.add_file = _add_file_skip_missing_sdk
